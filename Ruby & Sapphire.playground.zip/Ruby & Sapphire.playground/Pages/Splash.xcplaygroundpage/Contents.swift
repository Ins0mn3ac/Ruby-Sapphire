import SwiftUI
import PlaygroundSupport



struct ContentView: View {
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "papere")!)
                }
                .frame(width: 400, height: 600)
    }
}



PlaygroundPage.current.setLiveView(ContentView())
//: [Start](@next)
