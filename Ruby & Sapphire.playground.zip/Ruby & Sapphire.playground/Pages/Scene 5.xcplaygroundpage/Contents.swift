//: [Previous](@previous)

import UIKit
import SwiftUI
import PlaygroundSupport

// Setting custom font
let cfURL = Bundle.main.url(forResource: "IndieFlower-Regular", withExtension: "ttf")! as CFURL

CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil)

struct ContentView: View {
//  Starting offset of dots
    @State var offsetRuby : CGFloat = -20
    @State var offsetSapphire : CGFloat = 20
    @State var offsetAmethyst : CGFloat = 0
//   Variables that contain the animations times
    let animationDuration: Double = 1
    let animationDelay : Double = 1.8

    @State var isDotMoving = false
    @State var isRubyFading = true
    @State var isSapphireFading = true
    @State var isAmethystShowing = false

    var body: some View {
     
//       VStack containing all the elements
           VStack {
            Spacer(minLength: 30)
            
//         ZStack containing Ruby, Sapphire and Amethyst's HStack
            ZStack {
//         HStack containing Amethyst
            HStack {
            
            // MARK: Amethyst
                    Image(uiImage: UIImage(named: "amethyst")!)
                               .resizable()
                               .scaledToFit()
                               .padding()
                               .shadow(radius:15)
                               .offset(x: offsetAmethyst)
                               .opacity(isAmethystShowing ? 1 : 0)
                               .frame(width: 200, height: 200)
            //            Amethyst's static animation
                               .rotationEffect(isDotMoving ? .zero : Angle.degrees(5))
                               .animation(.linear(duration : 1).repeatForever(autoreverses: true), value: isDotMoving)

                               .onAppear() {
                                   isDotMoving = true
                                   withAnimation(.spring().delay(3)) {
                                       self.isAmethystShowing.toggle()

                                   }
                               }
            }
//         HStack containing Ruby and Sapphire
        HStack (spacing: 50) {

// MARK: Sapphire
                    Image(uiImage: UIImage(named: "sapphire")!)
                               .resizable()
                               .scaledToFit()
                               .padding()
                               .shadow(radius:15)
                               .offset(x: offsetSapphire)
                               .opacity(isSapphireFading ? 1 : 0)
                               .frame(width: 190, height: 190)
            //            Sapphire static animation
                               .rotationEffect(isDotMoving ? .zero : Angle.degrees(-5))
                               .animation(.linear(duration : 1).repeatForever(autoreverses: true), value: isDotMoving)

                               .onAppear() {
                                   isDotMoving = true
           //            Moving Sapphire on appear
                                   withAnimation(.linear(duration: animationDuration).delay(animationDelay)) {
                                       self.offsetSapphire = 120
                                       self.isSapphireFading.toggle()

                                   }
                                   
                               }

            
                            
            
// MARK: Ruby
                    Image(uiImage: UIImage(named: "ruby")!)
                               .resizable()
                               .scaledToFit()
                               .padding()
                               .shadow(radius:15)
                               .offset(x: offsetRuby)
                               .opacity(isRubyFading ? 1 : 0)
                               .frame(width: 190, height: 190)
            //            Ruby's static animation
                               .rotationEffect(isDotMoving ? .zero : Angle.degrees(5))
                               .animation(.linear(duration : 1).repeatForever(autoreverses: true), value: isDotMoving)
            
                               .onAppear() {
                                   isDotMoving = true
            //            Moving Ruby on appear
                                   withAnimation(.linear(duration: animationDuration).delay(animationDelay)) {
                                       self.offsetRuby = -110
                                       self.isRubyFading.toggle()
                                   }
                                  
                               }
            
                     }
            }
            
            
// MARK: Story text
            
            Spacer()
            
            VStack {
                Spacer()
            Text ("Overcome with happiness, Ruby and Sapphire hugged each other so tightly that they blended together again.")
                    .padding()
                .font(.custom("Indie Flower", size: 20, relativeTo: .body))
           //     Setting text background
                .background(
                    Image(uiImage: UIImage(named: "textBackground")!)
                                .resizable()
                        .opacity(0.8)
                        .scaledToFill()
                )
                
            } .fixedSize(horizontal: false, vertical: true)
            Spacer()
            
        }
        
//        Setting frame size
                .frame(width: 400, height: 600)
//        Setting background
                .background(Image(uiImage: UIImage(named: "background")!))
        
       
       }
}


PlaygroundPage.current.setLiveView(ContentView())
//: [Start again](@next)
