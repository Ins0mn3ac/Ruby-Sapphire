//: [Previous](@previous)
import UIKit
import SwiftUI
import PlaygroundSupport
import AVFoundation

// Setting up custom font
let cfURL = Bundle.main.url(forResource: "IndieFlower-Regular", withExtension: "ttf")! as CFURL
CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil)

struct ContentView: View {
// Variabile necessaria per la riproduzione audio
    @State var audioPlayer: AVAudioPlayer?
//    variabile angolo di rotazione per il girotondo
    @State var angle : Double = 0.0
//    Variabile antispam dei suoni
    @State var played : Bool = false
    let color = Color("clear")
    var body: some View {
     
//       Vertical stack che contiene il testo e l'horizontal stack
        VStack {
            Spacer()



        HStack (spacing: 50) {

//Both dots
                    Image(uiImage: UIImage(named: "dotSpin")!)
                               .resizable()
                               .scaledToFit()
                               .padding()
//            animazione del girotondo
                               .rotationEffect(.degrees(angle))
                               .animation(.spring(response: 1, dampingFraction: 0.5, blendDuration: 3))
                     }
//            bottone per farli girare
            Spacer()
            HStack(spacing: 50){
                Button("Make us spin!"){
                    angle+=180
//                    self.playAudio(songName: "laugh", fileExtension: "mp3", duration: 6.0)
                }
                .scaledToFit()
                .padding(10)
                .font(.custom("Indie Flower", size: 20, relativeTo: .body))
                .foregroundColor(Color.black)
                .background(Image(uiImage: UIImage(named: "greenBackground")!).resizable())
                .overlay(RoundedRectangle(cornerRadius: 25)
                .stroke(color, lineWidth: 5)
                            
                            )
            }
//            Spacer()
//            MARK: Story text
            VStack {
                Spacer()
            Text ("Once upon a time in the city of paper there were two colored dots: Ruby and Sapphire.\n They were best friends and they loved to play together.")
                    .padding()
                    .font(.custom("Indie Flower", size: 22.5, relativeTo: .body))
//                Setup dello sfondo del testo
                .background(
                    Image(uiImage: UIImage(named: "textBackground")!)
                                .resizable()
                        .opacity(0.8)
                        .scaledToFill()
                )
                
            } .fixedSize(horizontal: false, vertical: true)
            Spacer()
            
        }
        
//        Impostazione dimensioni schermo
                .frame(width: 400, height: 600)
//        Impostazione sfondo
                .background(Image(uiImage: UIImage(named: "background")!))
        
       
       }
    
//    Funzione incredibile e molto oversofisticata per riprodurre audio
    func playAudio(songName: String, fileExtension: String, duration: Double) {
        

        
            if let audioURL = Bundle.main.url(forResource: songName, withExtension: fileExtension) {
                do {
                    if played == false {
                    try self.audioPlayer = AVAudioPlayer(contentsOf: audioURL)
                    self.audioPlayer?.numberOfLoops = 0
                    
                        played = true
                        var timer=Timer.scheduledTimer(withTimeInterval: duration, repeats: false) { timer in
                            print("Audio Cue!")
                            played = false
                            
                        }
                    self.audioPlayer?.play()
                    }
                    
                } catch {
                    print("Couldn't play audio. Error: \(error)")
                }
                
            } else {
                print("No audio file found")
            }
        }

}



PlaygroundPage.current.setLiveView(ContentView())

//: [Next](@next)
