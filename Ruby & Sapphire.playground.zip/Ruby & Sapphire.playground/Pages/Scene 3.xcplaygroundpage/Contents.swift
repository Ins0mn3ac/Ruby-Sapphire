//: [Previous](@previous)
import UIKit
import SwiftUI
import PlaygroundSupport

let cfURL = Bundle.main.url(forResource: "IndieFlower-Regular", withExtension: "ttf")! as CFURL

CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil)

struct ContentView: View {
    @State var isDotMoving = false
    @State var fadeInOut = false
    @State var sizeOfBody1 : CGFloat = 130
    @State var sizeOfBody2 : CGFloat = 110
    var body: some View {

        VStack (spacing: 130) {
            
            ZStack{
                
            HStack {
           
// MARK: Genitore 1 (Sapphire's family)
                
                Image(uiImage: UIImage(named: "parent1")!)
                    .resizable()
                    .scaledToFit()
                   .scaledToFill()
                   .frame(width: sizeOfBody1, height: sizeOfBody1)
                   .padding()
                   .shadow(radius:15)
//  character animation (FadeInOut Spread)
                   .onAppear(){
                       withAnimation(Animation.easeInOut(duration: 1.5) .repeatForever(autoreverses: true) ) {
                           fadeInOut.toggle()
                           sizeOfBody1-=10
                       }
                   }.opacity(fadeInOut ? 0.2 : 1)
                
  
//MARK: Ametist

                
            Image(uiImage: UIImage(named: "amethyst")!)
                       .resizable()
                       .scaledToFit()
                       .scaledToFill()
                       .frame(width: 80, height: 80)
                       .padding()
                       .shadow(radius:15)
//  Rotation animation
                       .rotationEffect(isDotMoving ? .zero : Angle.degrees(15))
                       .animation(.linear(duration : 1).repeatForever(autoreverses: true), value: isDotMoving)
                       .onAppear() {
                           isDotMoving = true
                       }
                
            
                
// MARK: Genitore 2 (Ruby's family)
                
                    Image(uiImage: UIImage(named: "parent2")!)
                               .resizable()
                               .scaledToFit()
                               .scaledToFill()
                               .frame(width: sizeOfBody2, height: sizeOfBody2)
                               .padding()
                               .shadow(radius:15)
//  character animation (FadeInOut Spread)
                               .onAppear(){
                                   withAnimation(Animation.easeInOut(duration: 2) .repeatForever(autoreverses: true)) {
                                       fadeInOut.toggle()
                                       sizeOfBody2-=10
                                   }
                               }.opacity(!fadeInOut ? 0.2 : 1)
             
            }.frame(width: 130, height: 130)
            }
      
//  Caption of the scene
        
    
            
            Text ("When they were tired they went home. But both families did not recognize their children leaving them alone and sad.")
                .multilineTextAlignment(.center)
                .font(.custom("Indie Flower", size: 25, relativeTo: .body))
                .background(
                    Image(uiImage: UIImage(named: "textBackground")!)
                        .resizable()
                        .scaledToFill()
                )
        
        }
        
        
                .frame(width: 400, height: 600)
//        Background with image
                .background(Image(uiImage: UIImage(named: "background")!))
       
       }


}

PlaygroundPage.current.setLiveView(ContentView())
//: [Next](@next)
