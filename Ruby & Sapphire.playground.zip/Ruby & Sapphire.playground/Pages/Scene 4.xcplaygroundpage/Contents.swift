//: [Previous](@previous)
import UIKit
import SwiftUI
import PlaygroundSupport

// Setting custom font
let cfURL = Bundle.main.url(forResource: "IndieFlower-Regular", withExtension: "ttf")! as CFURL

CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil)

struct ContentView: View {
        
//  Starting offset of tears
    @State var offsetTears : CGFloat = 1000
//   Variables that contain the animations times
    let animationDuration: Double = 1
    let animationDelay : Double = 3

    @State var isDotMoving = false
    @State var isRubyShowing = false
    @State var isSapphireShowing = false
    @State var isAmethystShowing = true

    var body: some View {
        
        ZStack {
            
            VStack {
            
            HStack (spacing: 50) {

    // MARK: Sapphire
                        Image(uiImage: UIImage(named: "sapphire")!)
                                   .resizable()
                                   .scaledToFit()
                                   .padding()
                                   .shadow(radius:15)
                                   .opacity(isSapphireShowing ? 1 : 0)
                                   .frame(width: 190, height: 190)
                //            Sapphire's static animation
                                   .rotationEffect(isDotMoving ? .zero : Angle.degrees(-5))
                                   .animation(.linear(duration : 1).repeatForever(autoreverses: true), value: isDotMoving)
                //            Sapphire appears
                                   .onAppear() {
                                       isDotMoving = true
                                       withAnimation(.linear(duration: animationDuration).delay(animationDelay)) {
                                           self.isSapphireShowing.toggle()

                                       }
                                       
                                   }

                
    // MARK: Ruby
                        Image(uiImage: UIImage(named: "ruby")!)
                                   .resizable()
                                   .scaledToFit()
                                   .padding()
                                   .shadow(radius:15)
                                   .opacity(isRubyShowing ? 1 : 0)
                                   .frame(width: 190, height: 190)
                //            Ruby's static animation
                                   .rotationEffect(isDotMoving ? .zero : Angle.degrees(5))
                                   .animation(.linear(duration : 1).repeatForever(autoreverses: true), value: isDotMoving)
                //            Ruby appears
                                   .onAppear() {
                                       isDotMoving = true
                                       withAnimation(.linear(duration: animationDuration).delay(animationDelay)) {
    //                                       self.offsetRuby = -110
                                           self.isRubyShowing.toggle()
                                       }
                                      
                                   }
            }
                
                // MARK: Story text


                            Text ("Amethyst started to cry so much that it split back again into Ruby and Sapphire. But their sadness made their families understand that they had made a mistake.")
                                    .padding(30)
                                .font(.custom("Indie Flower", size: 21, relativeTo: .body))
                           
                //                Setting text background
                                .background(
                                    Image(uiImage: UIImage(named: "textBackground")!)
                                        .resizable()
                                        .opacity(0.8)
                                        .scaledToFill()
                                )
            
            
            }.fixedSize(horizontal: false, vertical: true)
            
            //          HStack containing Amethyst
                        HStack {
                        
                        // MARK: Amethyst
                            
                                Image(uiImage: UIImage(named: "amethyst")!)
                                           .resizable()
                                           .scaledToFit()
                                           .padding()
                                           .shadow(radius:15)
                                           .opacity(isAmethystShowing ? 1 : 0)
                                           .frame(width: 200, height: 200)
                                           .offset(y: -90)
                        //            Amethyst's static animation
                                           .rotationEffect(isDotMoving ? .zero : Angle.degrees(5))
                                           .animation(.linear(duration : 1).repeatForever(autoreverses: true), value: isDotMoving)
                        //            Amethyst disappears
                                           .onAppear() {
                                               isDotMoving = true
                                               withAnimation(.linear(duration: 1).delay(3)) {
                                                   self.isAmethystShowing.toggle()

                                               }
                                           }

                        }
            
//             MARK: Tears
                                                   Image(uiImage: UIImage(named: "tears")!)
                                                       .frame(width:400)
                                                       .offset(y: offsetTears)
                                   //                Tears animation
                                                       .onAppear{
                                                           withAnimation(Animation.linear(duration: 3) .repeatCount(1, autoreverses: true)) {
                                                           self.offsetTears = 50
                                                       }
                                                           withAnimation(Animation.linear(duration: 3).delay(3.2) .repeatCount(1, autoreverses: true)) {
                                                           self.offsetTears = 1000
                                                           }
                                                   }
            
        }
        
        
        
        
        
        //        Setting frame size
                        .frame(width: 400, height: 600)
        //        Setting background
                        .background(Image(uiImage: UIImage(named: "background")!))
        
}
    
    
}

PlaygroundPage.current.setLiveView(ContentView())
//: [Next](@next)
